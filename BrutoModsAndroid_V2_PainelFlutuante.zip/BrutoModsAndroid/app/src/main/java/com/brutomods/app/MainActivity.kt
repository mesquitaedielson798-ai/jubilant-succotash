package com.brutomods.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 9, 13)
    private val panel = Color.rgb(20, 20, 29)
    private val purple = Color.rgb(182, 76, 255)
    private val white = Color.WHITE
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("bruto_settings", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(16).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
    private fun button(label: String, onClick: () -> Unit): TextView =
        text(label, 14f, white, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(12), dp(13), dp(12), dp(13))
            background = rounded(panel, purple); setOnClickListener { onClick() }
        }
    private fun margin(l: Int, t: Int, r: Int, b: Int) =
        LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun page(title: String, subtitle: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(16))
        }
        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(text("BRUTO MODS  /  V1", 12f, purple, true), margin(0, 0, 0, 8))
        inner.addView(text(title, 27f, white, true), margin(0, 0, 0, 4))
        inner.addView(text(subtitle, 13f, Color.LTGRAY), margin(0, 0, 0, 18))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(content); scroll.addView(inner)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        listOf("HOME", "AIM", "ESP", "MISC", "SOBRE").forEach { tab ->
            val t = text(tab, 10f, if (tab == title.uppercase()) purple else white, true)
            t.gravity = Gravity.CENTER; t.setPadding(dp(5), dp(12), dp(5), dp(12))
            t.setOnClickListener { when (tab) {
                "HOME" -> showHome()
                "AIM" -> showAim()
                "ESP" -> showEsp()
                "MISC" -> showMisc()
                else -> showAbout()
            } }
            nav.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav); setContentView(root)
    }

    private fun addCard(title: String, description: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(panel)
        }
        box.addView(text(title, 15f, white, true))
        box.addView(text(description, 12f, Color.LTGRAY), margin(0, 4, 0, 0))
        content.addView(box, margin(0, 0, 0, 10))
    }
    private fun addSwitch(label: String, key: String, default: Boolean = false) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(10), dp(10)); background = rounded(panel)
        }
        row.addView(text(label, 14f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            buttonTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                if (::status.isInitialized) status.text = "$label: " + if (checked) "ATIVADO" else "DESATIVADO"
            }
        }
        row.addView(sw); content.addView(row, margin(0, 0, 0, 8))
    }

    private fun showHome() {
        page("Home", "PAINEL ANDROID • ESTILO NEON ROXO")
        addCard("BEM-VINDO", "Interface escura, detalhes neon e controles rápidos.")
        addCard("PAINEL FLUTUANTE", "Ative para deixar o painel por cima de outros aplicativos. Pode arrastar, recolher ou fechar.")
        content.addView(button("ATIVAR PAINEL NA TELA") {
            startActivity(Intent(this, OverlayPermissionActivity::class.java))
        }, margin(0, 0, 0, 10))
        content.addView(button("DESATIVAR PAINEL FLUTUANTE") {
            stopService(Intent(this, FloatingPanelService::class.java))
            Toast.makeText(this, "Painel flutuante desativado.", Toast.LENGTH_SHORT).show()
        }, margin(0, 0, 0, 10))
        content.addView(button("ABRIR SOBRE") { showAbout() }, margin(0, 0, 0, 10))
        status = text("Pronto para configurar.", 12f, purple, true)
        content.addView(status, margin(2, 4, 0, 0))
    }
    private fun showAim() {
        page("Aim", "CONTROLES VISUAIS DO PAINEL")
        addSwitch("Assistente visual", "aim_visual")
        addSwitch("Círculo FOV (prévia)", "aim_fov")
        content.addView(text("Sensibilidade: ${prefs.getInt("sensitivity", 50)}%", 13f, white, true), margin(0, 8, 0, 4))
        val seek = SeekBar(this).apply {
            max = 100; progress = prefs.getInt("sensitivity", 50)
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { prefs.edit().putInt("sensitivity", p).apply() }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        content.addView(seek, margin(0, 0, 0, 12))
        addCard("OBSERVAÇÃO", "Esses controles salvam preferências no aplicativo e não alteram a mira do jogo.")
    }
    private fun showEsp() {
        page("ESP", "PRÉVIA DE DEMONSTRAÇÃO")
        addSwitch("Mostrar nomes fictícios", "esp_names", true)
        addSwitch("Mostrar barra de vida fictícia", "esp_health", true)
        addSwitch("Mostrar distância de exemplo", "esp_distance")
        val demo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(15, 25, 20), Color.rgb(45, 210, 130))
        }
        demo.addView(text("JOGADOR DEMO • 25 m", 13f, Color.rgb(100, 255, 170), true))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 72
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(50, 230, 130))
        }
        demo.addView(bar, margin(0, 8, 0, 4))
        demo.addView(text("VIDA DE EXEMPLO 72%", 11f, white))
        content.addView(demo, margin(0, 0, 0, 10))
        addCard("DEMONSTRAÇÃO", "Indicadores fictícios para testar a interface; não leem dados do Free Fire.")
    }
    private fun showMisc() {
        page("Misc", "PERSONALIZAÇÃO")
        addSwitch("Efeitos neon", "neon", true)
        addSwitch("Salvar configurações", "save_settings", true)
        content.addView(button("RESTAURAR PADRÕES") { prefs.edit().clear().apply(); showMisc() }, margin(0, 8, 0, 10))
        addCard("ARMAZENAMENTO", "As opções são guardadas localmente no Android.")
    }
    private fun showAbout() {
        page("Sobre", "INFORMAÇÕES DO APLICATIVO")
        addCard("BRUTO MODS V1", "Painel Android independente • interface escura com neon roxo.")
        addCard("PAINEL FLUTUANTE", "Pode ficar por cima de outros apps. Use os botões da Home para ativar ou desativar; no painel, — recolhe e × fecha.")
        addCard("CRÉDITOS", "Projeto demonstrativo BRUTO MODS.")
        addCard("IMPORTANTE", "Aim/ESP são apenas controles e prévias visuais. O aplicativo não está conectado ao Free Fire e não oferece funções reais de trapaça nem garantia anti-ban.")
        content.addView(button("VOLTAR AO INÍCIO") { showHome() }, margin(0, 0, 0, 10))
    }
}
