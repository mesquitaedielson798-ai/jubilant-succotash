package com.brutomods.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private val purple = Color.rgb(182, 76, 255)
    private val bg = Color.rgb(15, 15, 22)
    private val prefs by lazy { getSharedPreferences("bruto_settings", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (root == null) createPanel()
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(14).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun txt(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun createPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            dp(245), WindowManager.LayoutParams.WRAP_CONTENT, windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(150) }
        lp = params

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = shape(bg, purple)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = txt("BRUTO MODS", 14f, purple, true)
        header.addView(title, LinearLayout.LayoutParams(0, dp(36), 1f))
        val collapse = txt("—", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0)
        }
        val close = txt("×", 24f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(5), 0, dp(3), 0)
        }
        header.addView(collapse, LinearLayout.LayoutParams(dp(32), dp(36)))
        header.addView(close, LinearLayout.LayoutParams(dp(28), dp(36)))
        panel.addView(header)

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun switchRow(caption: String, key: String, default: Boolean = false) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(6), dp(4), dp(6))
            }
            row.addView(txt(caption, 12f), LinearLayout.LayoutParams(0, dp(38), 1f))
            val sw = Switch(this).apply {
                isChecked = prefs.getBoolean(key, default)
                buttonTintList = android.content.res.ColorStateList.valueOf(purple)
                setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
            }
            row.addView(sw)
            body.addView(row)
        }
        switchRow("Assistente visual", "aim_visual")
        switchRow("Círculo FOV (prévia)", "aim_fov")
        switchRow("Nomes de demonstração", "esp_names", true)
        switchRow("Barra de vida fictícia", "esp_health", true)

        val about = txt("SOBRE  •  BRUTO MODS V1", 11f, purple, true).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        body.addView(about)
        val aboutText = txt("Painel flutuante independente. Opções apenas visuais; não modifica o Free Fire.", 10f, Color.LTGRAY)
        body.addView(aboutText)
        panel.addView(body)

        collapse.setOnClickListener {
            val collapsed = body.visibility == View.GONE
            body.visibility = if (collapsed) View.VISIBLE else View.GONE
            collapse.text = if (collapsed) "—" else "+"
        }
        close.setOnClickListener { stopSelf() }

        // Arraste o cabeçalho para mover o painel pela tela.
        header.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        touchX = event.rawX; touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        wm.updateViewLayout(panel, params)
                        return true
                    }
                }
                return false
            }
        })
        root = panel
        wm.addView(panel, params)
    }

    override fun onDestroy() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }
}
