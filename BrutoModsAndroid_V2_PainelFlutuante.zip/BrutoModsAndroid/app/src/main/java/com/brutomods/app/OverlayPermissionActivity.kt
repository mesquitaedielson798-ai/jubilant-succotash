package com.brutomods.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

class OverlayPermissionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                71
            )
        } else startPanel()
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 71) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                startPanel()
            } else {
                Toast.makeText(this, "Permita aparecer sobre outros apps para ativar o painel.", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun startPanel() {
        startService(Intent(this, FloatingPanelService::class.java))
        Toast.makeText(this, "Painel flutuante ativado.", Toast.LENGTH_SHORT).show()
        finish()
    }
}
