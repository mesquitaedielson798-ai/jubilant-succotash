# BRUTO MODS V2 — Painel flutuante Android

Projeto-fonte Android nativo em Kotlin, com tema preto e neon roxo.

## O que inclui
- Abas no aplicativo principal: Home, Aim, ESP, Misc e Sobre.
- Painel flutuante por cima de outros aplicativos, após conceder a permissão de sobreposição.
- No painel flutuante: controles locais, opção de recolher/expandir com `—` / `+`, arrastar pelo cabeçalho e fechar com `×`.
- Na Home: botões para ativar e desativar o painel flutuante.
- Preferências locais guardadas no Android.
- Prévia de ESP com nome e barra de vida fictícios.

## Como compilar
1. Extraia o ZIP.
2. Abra a pasta `BrutoModsAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Escolha **Build > Build APK(s)**.
5. Instale o APK gerado.
6. Abra o app e toque em **ATIVAR PAINEL NA TELA**. Autorize **Aparecer sobre outros apps** nas configurações do Android.

## Limites
O projeto é um painel independente de demonstração. Os controles Aim/ESP e os indicadores são locais/fictícios: não leem dados do Free Fire, não fazem mira automática nem revelam jogadores reais. Não inclui bypass ou garantia anti-ban. O projeto-fonte não foi compilado nem testado em dispositivo nesta sessão.
